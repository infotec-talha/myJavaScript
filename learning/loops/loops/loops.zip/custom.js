function println(input)
{
 document.write(input,"<br/>");
}